BOT_TOKEN = '7248725382:AAH-vmfyG26bcX63PVr5slQ18ACQ4ygBDLU'

PREFIX = "!/."

ANTISPAM = int(120)

OWNER = 1912413450

APP_ID = ""

API_HASH = ''

SESSION = ""

OWNERID = int(1912413450)

OWNER_NAME = "<a href='tg://user?id=1912413450'>⏤͟͞B3</a>"

CHANNEL = "https://t.me/PatilScripter"

GROUP = "https://t.me/PatilChat"

OWNER_LINK = "https://t.me/Patil9200"

from database import check_user, check_admin

def check_owner(id):
  if id == OWNER: return True
def ok(id):
  if check_owner(id):
    user = "OWNER"
    return user
  if check_admin(id) == True:
    user = "ADMIN"
    return user

  elif check_user(id) == True:
    user = "PAID"
    return user

  elif check_user(id) == False or check_admin(id) == False:
    user = "FREE"
    return user

  else:
    user = "FREE"
    return user
